
package com.acapra.app.model;
import jakarta.persistence.*;


@Entity 
public class Animal {
    @Id @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    private String nome;
    private String especie;
    private String idade;
    private String porte;
    private String sexo;
    private String saude;
    @Column(length=1000)
    private String descricao;
    private String imagemUrl;

    public Animal() {}
    public Animal(Long id, String nome, String especie, String idade, String porte, String sexo, String saude, String descricao, String imagemUrl) {
        this.id = id;
        this.nome = nome;
        this.especie = especie;
        this.idade = idade;
        this.porte = porte;
        this.sexo = sexo;
        this.saude = saude;
        this.descricao = descricao;
        this.imagemUrl = imagemUrl;
    }
    public Long getId() { return this.id; }
    public void setId(Long id) { this.id = id; }
    public String getNome() { return this.nome; }
    public void setNome(String nome) { this.nome = nome; }
    public String getEspecie() { return this.especie; }
    public void setEspecie(String especie) { this.especie = especie; }
    public String getIdade() { return this.idade; }
    public void setIdade(String idade) { this.idade = idade; }
    public String getPorte() { return this.porte; }
    public void setPorte(String porte) { this.porte = porte; }
    public String getSexo() { return this.sexo; }
    public void setSexo(String sexo) { this.sexo = sexo; }
    public String getSaude() { return this.saude; }
    public void setSaude(String saude) { this.saude = saude; }
    public String getDescricao() { return this.descricao; }
    public void setDescricao(String descricao) { this.descricao = descricao; }
    public String getImagemUrl() { return this.imagemUrl; }
    public void setImagemUrl(String imagemUrl) { this.imagemUrl = imagemUrl; }
}