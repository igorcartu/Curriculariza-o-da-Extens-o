
package com.acapra.app.model;
import jakarta.persistence.*;

import java.time.LocalDateTime;

@Entity 
public class Adocao {
    @Id @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    private String nome;
    private String email;
    private String animal;
    @Column(length=2000)
    private String motivo;
    private LocalDateTime criadoEm = LocalDateTime.now();

    public Adocao() {}
    public Adocao(Long id, String nome, String email, String animal, String motivo) {
        this.id = id;
        this.nome = nome;
        this.email = email;
        this.animal = animal;
        this.motivo = motivo;
    }
    public Long getId() { return this.id; }
    public void setId(Long id) { this.id = id; }
    public String getNome() { return this.nome; }
    public void setNome(String nome) { this.nome = nome; }
    public String getEmail() { return this.email; }
    public void setEmail(String email) { this.email = email; }
    public String getAnimal() { return this.animal; }
    public void setAnimal(String animal) { this.animal = animal; }
    public String getMotivo() { return this.motivo; }
    public void setMotivo(String motivo) { this.motivo = motivo; }
}