
package com.acapra.app.repo;
import org.springframework.data.jpa.repository.JpaRepository;
import com.acapra.app.model.*;
import java.util.Optional;

public interface AnimalRepo extends JpaRepository<Animal, Long> {}
public interface AdocaoRepo extends JpaRepository<Adocao, Long> {}
public interface UsuarioRepo extends JpaRepository<Usuario, Long> {
    Optional<Usuario> findByUsername(String username);
}
