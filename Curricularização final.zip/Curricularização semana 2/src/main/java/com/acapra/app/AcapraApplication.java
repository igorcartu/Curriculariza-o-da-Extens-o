
package com.acapra.app;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class AcapraApplication {
    public static void main(String[] args) {
        SpringApplication.run(AcapraApplication.class, args);
    }
}
